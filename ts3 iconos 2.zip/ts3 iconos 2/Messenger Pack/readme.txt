Diese Teamspeak 3 Icons werden von skywalger.de bereitgestellt.

Das direkte verlinken der Datei ist untersagt. Bitte auf die Downloadseite verlinken.

